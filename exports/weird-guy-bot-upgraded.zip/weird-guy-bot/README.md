# Weird Guy Bot — Upgraded Export

This package contains the upgraded Discord bot source.

## Included upgrades

- Per-server configuration stored independently by Discord server ID
- Server administrators can change only their own server's settings with `,wgconfig`
- Discord Administrator permission and approved administrator-role support
- AI personality and AI-on-mention settings per server
- Per-server automod, logging, prefix, leveling, XP, and announcement settings
- Persistent XP, warnings, moderation notes, and premium users
- Protected moderation targets
- Owner-only global controls remain separate from server configuration
- One-shot launcher: the bot does not automatically restart after it stops

## Server configuration

Use `,wgconfig` inside a server. Only that server's Discord administrators or configured admin roles can change settings. These commands always use the current message's server ID; they cannot edit another server's settings.

Examples:

- `,wgconfig show`
- `,wgconfig prefix !`
- `,wgconfig aimode cringe`
- `,wgconfig automod off`
- `,wgconfig levels on`
- `,wgconfig levelchannel #announcements`

## Setup

1. Install Node.js dependencies from the project root with `pnpm install`.
2. Set `TOKEN`, `OWNER_ID`, and `OWNER_PASSWORD` as private environment variables/secrets.
3. Configure the Replit AI integration variables shown in `.env.example`.
4. Start the bot with `node bot/start.js`.

The bot writes runtime state to `bot/data/state.json`. That file is intentionally not included in this export and will be created automatically on first run.
