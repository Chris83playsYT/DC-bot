# Export notes

This archive contains source code and workspace manifests, not `node_modules`, compiled output, caches, Git history, or local secrets.

The owner password fallback was removed from this export. Configure `OWNER_PASSWORD` in a private environment file before running owner commands.
