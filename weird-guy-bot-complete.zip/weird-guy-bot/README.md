# Weird Guy Discord Bot

A Discord hangout bot with AI conversation, fun commands, moderation and security tools, owner/admin controls, premium users, a watchdog restart process, and a health endpoint for uptime monitoring.

## Included

- `bot/` — Discord bot commands, handlers, AI integration, premium system, logging, automod, keepalive server, and watchdog
- `artifacts/api-server/` — HTTP health API, including `/api/ping`
- `lib/` — shared API, validation, database, and code-generation packages used by the server
- `run-production.sh` — starts the API server and Discord bot watchdog together
- `.env.example` — environment variable template

## Setup

1. Install Node.js 20+ and pnpm.
2. Copy `.env.example` to `.env`.
3. Fill in the private values in `.env`:
   - `TOKEN`
   - `OWNER_PASSWORD`
   - `AI_INTEGRATIONS_OPENROUTER_API_KEY`
   - `AI_INTEGRATIONS_OPENROUTER_BASE_URL`
4. Install dependencies:

   ```bash
   pnpm install
   ```

5. Start the Discord bot directly:

   ```bash
   pnpm --filter @workspace/bot start
   ```

6. For the bot plus uptime API, use:

   ```bash
   ./run-production.sh
   ```

## UptimeRobot

When the API is publicly reachable, monitor:

```text
https://YOUR_PUBLIC_DOMAIN/api/ping
```

The endpoint returns a JSON response with `status: "alive"` while the API is running. A monitor can help wake or restart a hosted process, but 24/7 availability depends on the hosting provider's deployment settings.

## Security notes

- Never commit `.env` or share your Discord token.
- The exported copy intentionally does not contain any owner password value. Set `OWNER_PASSWORD` privately before starting the bot.
- Discord must be configured with the intents and permissions required by the commands you use.
